package it.polimi.softeng.pkg;

public abstract class ComplexAlgo {

    public void compute() {
        step1();
        step2();
    }

    protected abstract void step1();

    protected abstract void step2();
}
