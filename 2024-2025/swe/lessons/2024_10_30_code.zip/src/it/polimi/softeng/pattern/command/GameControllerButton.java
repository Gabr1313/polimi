package it.polimi.softeng.pattern.command;

// TODO implement
public class GameControllerButton {
}
