package it.polimi.softeng.pattern.abstractfactory;

public class DarkMenu extends Menu {

    @Override
    public String toString() {
        return "DarkMenu";
    }
}
