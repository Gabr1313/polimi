package it.polimi.softeng.concurrency;

import it.polimi.softeng.concurrency.exercises.HydraulicSystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

public class Main {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        Thread t = new MyThread();
        t.start();
        System.out.println("Ciao Ciao");
        t.join();
        System.out.println("Ciao ancora");

        final int j = 0;
        Thread t1 = new Thread(() -> {
            System.out.println("Hello " + j);
            System.out.println("Hello Hello");
        });
        t1.start();
        t1.join();

        BankAccont account = new BankAccont(1000);
        // Non posso togliere il commento sotto,
        // altrimenti account non e' piu' final
        // account = new BankAccont(2000);
        Thread tDep = new Thread(() -> {
            for (int i=0; i<10000; i++) {
                account.deposit(1);
            }
        });
        Thread tWithdraw = new Thread(() -> {
            for (int i=0; i<10000; i++) {
                account.withdraw(1);
            }
        });
        tDep.start();
        tWithdraw.start();
        tDep.join();
        tWithdraw.join();
        System.out.println(account.getBalance());

        BankAccont a1 = new BankAccont(1000);
        BankAccont a2 = new BankAccont(1000);

        new Thread(() -> {
            for (int i=0; i<10000; i++) {
                a1.transfer(a2, 100);
            }
        }).start();

        new Thread(() -> {
            for (int i=0; i<10000; i++) {
                a2.transfer(a1, 100);
            }
        }).start();

        ExecutorService executor = Executors.newFixedThreadPool(4);
        executor.submit(() -> System.out.println("Hello"));
        executor.submit(() -> System.out.println("HelloHello"));
        executor.shutdown();
        while(!executor.awaitTermination(10, TimeUnit.SECONDS)) {};


        ExecutorService executor2 = Executors.newFixedThreadPool(4);
        Future<String> var1 = executor2.submit(() -> "Hello");
        Future<String> var2 = executor2.submit(() -> "HelloHello");

        // Faccio tante cose..... passa tempo....
        String var1Contents = var1.get();

        executor2.shutdown();
        while(!executor2.awaitTermination(10, TimeUnit.SECONDS)) {};

        List<String> myList = new ArrayList<>();
        myList = Collections.synchronizedList(myList);

        Map<String, Integer> map = new ConcurrentHashMap<>();

        HydraulicSystem myHs = new HydraulicSystem(100);
        new Thread(() -> {
            while (true) {
                myHs.swap(1,2,10);
                myHs.swap(2,1,10);
            }
        }).start();

    }

}
