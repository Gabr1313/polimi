package it.polimi.softeng.pattern.abstractfactory;

public class LightWindow extends Window {

    @Override
    public String toString() {
        return "LightWindow";
    }
}
