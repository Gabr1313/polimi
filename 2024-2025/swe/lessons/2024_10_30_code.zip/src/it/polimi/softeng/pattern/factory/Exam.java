package it.polimi.softeng.pattern.factory;

public abstract class Exam { }
