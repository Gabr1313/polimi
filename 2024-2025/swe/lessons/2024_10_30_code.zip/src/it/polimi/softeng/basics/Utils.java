package it.polimi.softeng.basics;

public class Utils {

    public void swap(Data d1, Data d2) {
        Data temp = d1;
        d1 = d2;
        d2 = temp;
    }
}
