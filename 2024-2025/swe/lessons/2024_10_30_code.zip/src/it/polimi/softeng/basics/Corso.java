package it.polimi.softeng.basics;

public class Corso {
    private final Student[] students;
    private int numStudents;

    public Corso() {
        this.students = new Student[400];
        this.numStudents = 0;
    }

    public void addStudent(Student student) {
        this.students[numStudents] = student;
        numStudents++;
    }

    public int sum() {
        int sum = 0;
        for (int i = 0; i < numStudents; i++) {
            sum += students[i].getVoto();
        }
        return sum;
    }

    public int sum1() {
        int sum = 0;
        for (Student s : students) {
            sum += s.getVoto();
        }
        return sum;
    }
}
