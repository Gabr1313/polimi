package it.polimi.softeng.concurrency;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ContactBook {
    private final Map<String, Integer> contacts;
    private final ReadWriteLock lock;

    public ContactBook() {
        this.contacts = new HashMap<>();
        this.lock = new ReentrantReadWriteLock();
    }

    public void add(String name, int num) {
        lock.writeLock().lock();
        this.contacts.put(name, num);
        lock.writeLock().unlock();
    }

    public int get(String name) {
        int result = 0;
        lock.readLock().lock();
        result = this.contacts.get(name);
        lock.readLock().unlock();
        return result;
    }
}
