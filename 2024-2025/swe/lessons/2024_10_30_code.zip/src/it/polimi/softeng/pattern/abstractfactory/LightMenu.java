package it.polimi.softeng.pattern.abstractfactory;

public class LightMenu extends Menu {

    @Override
    public String toString() {
        return "LightMenu";
    }
}
