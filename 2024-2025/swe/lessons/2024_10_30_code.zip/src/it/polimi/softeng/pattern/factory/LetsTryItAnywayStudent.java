package it.polimi.softeng.pattern.factory;

public class LetsTryItAnywayStudent extends Student {
    // TODO: add methods if needed
}
