package it.polimi.softeng.pattern.observer;

public class UserInterface {

    public void click() {
        // Multiple different components need to learn about the click
    }
}
