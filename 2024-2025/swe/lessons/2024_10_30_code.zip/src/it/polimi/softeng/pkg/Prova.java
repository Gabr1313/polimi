package it.polimi.softeng.pkg;

public class Prova {
    protected int attr;

    public Prova() {
        super();
    }

    @Override
    public String toString() {
        return "Sono una prova con attributo " + attr;
    }

    @Override
    public final boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Prova prova)) return false;

        return attr == prova.attr;
    }

    @Override
    public int hashCode() {
        return attr;
    }
}
