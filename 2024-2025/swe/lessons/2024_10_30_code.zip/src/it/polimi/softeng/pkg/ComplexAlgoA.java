package it.polimi.softeng.pkg;

public class ComplexAlgoA extends ComplexAlgo {
    @Override
    protected void step1() {

    }

    @Override
    protected void step2() {

    }
}
