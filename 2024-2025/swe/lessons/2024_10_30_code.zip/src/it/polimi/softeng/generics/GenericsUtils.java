package it.polimi.softeng.generics;

import it.polimi.softeng.exceptions.EmptyListException;

import java.util.List;

public class GenericsUtils {

    public static <T> T getFirst(List<T> list) throws EmptyListException {
        if (list.isEmpty()) {
            throw new EmptyListException("List is empty");
        }
        return list.get(0);
    }

    public static <T extends Comparable<T>> T getMax(List<T> list) {
        if (list.isEmpty()) return null;
        else {
            T max = list.get(0);
            for (int i = 1; i < list.size(); i++) {
                if (max.compareTo(list.get(i)) < 0) {
                    max = list.get(i);
                }
            }
            return max;
        }
    }
}
