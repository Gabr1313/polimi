package it.polimi.softeng.generics;

import java.util.Iterator;

public class Pair<T> implements Iterable<T> {
    private T first;
    private T second;

    public Pair(T first, T second) {
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }

    public T getSecond() {
        return second;
    }

    @Override
    public Iterator<T> iterator() {
        return new PairIterator(this);
    }

    private class PairIterator implements Iterator<T> {
        private Pair<T> pair;
        private int current;

        public PairIterator(Pair<T> pair) {
            this.pair = pair;
            this.current = 0;
        }

        @Override
        public boolean hasNext() {
            return current < 2;
        }

        @Override
        public T next() {
            if (current == 0) {
                current++;
                return pair.getFirst();
            } else if (current == 1) {
                current++;
                return pair.getSecond();
            } else {
                return null;
            }
        }
    }
}
