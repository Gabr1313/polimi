package it.polimi.softeng.concurrency;

public class MyThread extends Thread {

    @Override
    public void run() {
        System.out.println("Ciao");
    }
}
