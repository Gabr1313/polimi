package it.polimi.softeng.abstract_interfaces;

public abstract class Poligono {
    private final int numLati;

    public Poligono(int numLati) {
        this.numLati = numLati;
    }

    public int getNumLati() {
        return numLati;
    }

    public abstract void draw();
}
