package it.polimi.softeng.concurrency.exercises;

import java.util.ArrayList;
import java.util.List;

public class TodoList {
    private List<Task> completedTasks;
    private List<Task> pendingTasks;

    public TodoList() {
        completedTasks = new ArrayList<>();
        pendingTasks = new ArrayList<>();
    }

    public void add(Task task) {
        synchronized (pendingTasks) {
            pendingTasks.add(task);
        }
    }

    public void completeLast() {
        synchronized (pendingTasks) {
            Task t = pendingTasks.removeLast();
            t.complete();
            synchronized (completedTasks) {
                completedTasks.add(t);
            }
        }
    }

    public int size() {
        int size = 0;
        synchronized (completedTasks) {
            size += completedTasks.size();
        }
        synchronized (pendingTasks) {
            size += pendingTasks.size();
        }
        return size;
    }
}

class Task {
    public void complete() {

    }
}

// a) Nel suo insieme il codice evita il verificarsi
// di deadlock e di accessi concorrenti a zone condivise
// di memoria anche se i vari metodi fossero invocati
// da thread diversi? Motivare la propria risposta e in
// caso di risposta negativa spiegare cosa andrebbe cambiato
// per evitare deadlock o conflitti nell’accesso a memoria
// condivisa.

// b) Si aggiunga alla classe TodoList il metodo public
// Task get(int i) descritto nell’esercizio 1, facendo
// particolare attenzione agli aspetti di sincronizzazione.

// c) Si aggiunga alla classe TodoList il metodo
// public Task getFirstPending() che restituisce il primo
// compito non completato (pending) se presente, altrimenti
// sospende il chiamante in attesa che venga aggiunto un nuovo
// compito. Si chiarisca inoltre se e quali modifiche debbano
// essere fatte ai metodi esistenti.