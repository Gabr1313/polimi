package it.polimi.softeng.abstract_interfaces;

public class Quadrato extends Quadrilatero {
    @Override
    public void draw() {
        System.out.println("Quadrato");
    }
}
