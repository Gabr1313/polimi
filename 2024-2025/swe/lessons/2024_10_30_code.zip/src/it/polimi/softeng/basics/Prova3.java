package it.polimi.softeng.basics;

import it.polimi.softeng.pkg.Prova;

public class Prova3 extends Prova {

    public int calcolaIlDoppio() {
        return attr * 2;
    }
}
