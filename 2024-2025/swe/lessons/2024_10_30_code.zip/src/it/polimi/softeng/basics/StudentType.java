package it.polimi.softeng.basics;

public enum StudentType {
    ING("Ingegneria"),
    ARCH("Architettura"),
    DES("Design"),
    WRONG("Sorry :(");

    private String name;

    private StudentType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
