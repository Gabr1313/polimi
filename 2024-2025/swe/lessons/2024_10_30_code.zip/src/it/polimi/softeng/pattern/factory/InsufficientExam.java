package it.polimi.softeng.pattern.factory;

public class InsufficientExam extends Exam {

    @Override
    public String toString() {
        return "I'm insufficient, sigh :(";
    }
}
