package it.polimi.softeng.pattern.factory;

public class SufficientExam extends Exam {

    @Override
    public String toString() {
        return "I'm a sufficient exam :)";
    }
}
