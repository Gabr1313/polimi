package it.polimi.softeng.basics;

import it.polimi.softeng.abstract_interfaces.Printable;

public class Student extends Person implements Printable {
    private final int voto;
    private final StudentType type;

    public Student(String name, int age, int voto, StudentType type) {
        super(name, age);
        this.voto = voto;
        this.type = type;
    }

    public int getVoto() {
        return voto;
    }

    public int getInterest() {
        switch (type) {
            case ING -> {
                return 100;
            }
            case ARCH -> {
                return 50;
            }
            default -> {
                return 0;
            }
        }
    }

    @Override
    public void print() {
        System.out.println("Sono " + getName() + " e il mio voto e' " + voto);
    }

    public void print(int repetitions) {
        for (int i = 0; i < repetitions; i++) {
            print();
        }
    }
}
