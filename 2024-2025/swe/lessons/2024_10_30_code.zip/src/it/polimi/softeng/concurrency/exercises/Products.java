package it.polimi.softeng.concurrency.exercises;

import java.util.HashMap;
import java.util.Map;

// Tema 20230213
public class Products {
    private Map<Integer, String> idToName;
    private Map<String, Integer> nameToPrice;
    private int lastId;

    public Products() {
        idToName = new HashMap<>();
        nameToPrice = new HashMap<>();
        lastId = 0;
    }

    public synchronized int addProduct(String name, int price) {
        int assignedId = lastId++;
        idToName.put(assignedId, name);
        nameToPrice.put(name, price);
        notifyAll();
        return assignedId;
    }

    // Ritorna il prezzo del prodotto avente
    // l’id passato per parametro
    // Se tale prodotto non esiste, ritorna -1
    public synchronized int getPriceById(int id) throws InterruptedException {
        while (!idToName.containsKey(id)) {
            wait();
        }
        String name = idToName.get(id);
        return nameToPrice.get(name);
    }

    public void copyPrice(Products other) {
        Map<String, Integer> copy = null;
        synchronized (other) {
            copy = new HashMap<>(other.nameToPrice);
        }
        synchronized (this) {
            for (String name : copy.keySet()) {
                if (this.nameToPrice.containsKey(name)) {
                    int price = copy.get(name);
                    this.nameToPrice.put(name, price);
                }
            }
        }

    }
}

// a) Si dica se la classe Products e' opportunamente
// sincronizzata per permettere l’invocazione concorrente
// dei suoi metodi da parte di piu' thread.
// In caso negativo, si modifichi la classe per correggere
// la sua sincronizzazione.

// b) A partire dalla soluzione data alla domanda (a),
// si modifichi il metodo getPriceById in modo che,
// invece di ritornare -1, sospenda il chiamante se
// il prodotto non esiste. Se necessario, si indichi
// come modificare altri metodi.

// c) Si scriva un metodo void copyPrices(Products other)
// che, per tutti i prodotti di this che sono anche contenuti
// in other sostituisce i prezzi contenuti in this con
// i prezzi contenuti in other. Si presti particolare attenzione
// a evitare il rischio di possibili deadlock.