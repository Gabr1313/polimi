package it.polimi.softeng.pkg;

public class Prova2 {
    public static void main(String[] args) {
        Prova x = new Prova();
        x.attr = 2;
    }
}
