package it.polimi.softeng.basics;

public class Person {
    private final String name;
    private final int age;
    private static int numPersons = 0;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        numPersons++;
    }

    public static int getNumPersons() {
        return numPersons;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void print() {
        System.out.println("Sono " + name);
    }

}
