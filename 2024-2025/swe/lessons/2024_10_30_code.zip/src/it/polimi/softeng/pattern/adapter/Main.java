package it.polimi.softeng.pattern.adapter;

public class Main {
    // TODO: vorrei stampare un documento pdf Printable usando la libreria LibPDFFile
    public static void main(String[] args) {

    }
}
