package it.polimi.softeng.concurrency.exercises;

import java.util.ArrayList;
import java.util.List;

// Tema 20240115
public class Students {
    private List<String> studNames;
    private List<Integer> scores;

    public Students() {
        studNames = new ArrayList<>();
        scores = new ArrayList<>();
    }

    public int getScore(String studName) {
        synchronized(studNames) {
            int pos = studNames.indexOf(studName);
            if(pos==-1) return -1;
            else return scores.get(pos);
        }
    }

    public void addScore(String studName, int score) throws InterruptedException {
        synchronized(studNames) {
            while (getScore(studName) != -1) {
                studNames.wait();
            }
            studNames.add(studName);
            scores.add(score);
        }
    }

    public void clear() {
        synchronized(studNames) {
            studNames.clear();
            scores.clear();
            studNames.notifyAll();
        }
    }
}

// a) La sincronizzazione proposta evita il verificarsi
// di accessi concorrenti a zone di memoria condivise da
// parte di diversi thread? Motivare la propria risposta
// ed in caso di risposta negativa suggerire come sia
// possibile correggere il codice proposto, modificando
// al più un metodo.

// b) La sincronizzazione proposta garantisce che non
// possano essere inseriti duplicati (studenti con il
// medesimo nome)?
// Motivare la propria risposta ed in caso di risposta
// negativa suggerire come sia possibile correggere il
// codice proposto, modificando al più un metodo.

// c) Si modifichi il metodo addScore perche' sospenda
// il chiamante invece di sollevare l’eccezione.
// Indicare se altri metodi devono essere modificati e come.