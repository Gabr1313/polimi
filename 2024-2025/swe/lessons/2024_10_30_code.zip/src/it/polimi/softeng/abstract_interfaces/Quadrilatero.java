package it.polimi.softeng.abstract_interfaces;

public abstract class Quadrilatero extends Poligono {
    public Quadrilatero() {
        super(4);
    }
}
