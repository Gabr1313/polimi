package it.polimi.softeng.pattern.abstractfactory;

public class DarkWindow extends Window {

    @Override
    public String toString() {
        return "DarkWindow";
    }
}
