package it.polimi.softeng.pattern.abstractfactory;

public class Main {
    public static void main(String[] args) {
        // TODO: si vuole inizializzare un'interfaccia Dark con una finestra e un menu.
    }
}
