package it.polimi.softeng;

import it.polimi.softeng.abstract_interfaces.Poligono;
import it.polimi.softeng.abstract_interfaces.Printable;
import it.polimi.softeng.abstract_interfaces.Quadrato;
import it.polimi.softeng.abstract_interfaces.Triangolo;
import it.polimi.softeng.basics.*;
import it.polimi.softeng.exceptions.EmptyListException;
import it.polimi.softeng.generics.GenericsUtils;
import it.polimi.softeng.generics.Pair;
import it.polimi.softeng.pkg.Prova;
import it.polimi.softeng.polimorfismo.Punto2D;
import it.polimi.softeng.polimorfismo.Punto3D;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        int x = 1;
        Data d = new Data(23, 9, 2024);
        Data d1 = new Data(30, 9, 2024);

        Utils u = new Utils();
        u.swap(d, d1);
        System.out.println(d1.getGiorno());

        Person p1 = new Person("Nome", 32);
        Student s1 = new Student("Studente", 23, 17, StudentType.ING);
        Person p2 = new Student("Studente2", 24, 19, StudentType.ARCH);
        // Student s2 = new Person("Nome2", 44);

        Person p3 = s1;
        // Errore a compilazione s1 = p2;

        s1.getVoto();
        // Non compila perche' p2 ha tipo statico Person
        // p2.getVoto();

        p1.print();
        s1.print();
        p2.print();

        System.out.println(Person.getNumPersons());

        StudentType t1 = StudentType.ING;

        Corso ingSoft = new Corso();
        ingSoft.addStudent(s1);
        // ingSoft.sum1();

        Punto2D punto1 = new Punto2D(10, 10);
        Punto2D punto2 = new Punto3D(10, 10, 20);
        Punto3D punto3 = new Punto3D(10, 10, 40);

        punto1.distance(punto1);
        punto1.distance(punto2);
        punto1.distance(punto3);

        punto2.distance(punto1);
        punto2.distance(punto2);
        punto2.distance(punto3);

        punto3.distance(punto1);
        punto3.distance(punto2);
        punto3.distance(punto3);

        Poligono poli1 = new Triangolo();
        Poligono poli2 = new Quadrato();
        Triangolo t = new Triangolo();
        poli1.draw();
        poli2.draw();

        stampa(t);
        stampa(s1);

        Prova p = new Prova();
        System.out.println(p);

        Pair<String> pair1 = new Pair<>("Ciao", "Ciao1");
        Pair<Integer> pair2 = new Pair<>(1, 3);

        Integer i = 3;

        List<String> l1 = new LinkedList<>();
        l1 = new ArrayList<>();

        l1.add("Ciao");
        l1.add("CiaoCiao");
        System.out.println("La lista ha " + l1.size() + " elementi");

        for (String s : l1) {
            System.out.println(s);
        }

        // Quanto scritto sopra e' equivalente a questa notazione
        Iterator<String> it = l1.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        Set<String> set1 = new HashSet<>();
        set1.add("Ciao");
        set1.add("Ciao");
        set1.add("Ciao!");
        System.out.println("Il set ha " + set1.size() + " elementi");

        Map<String, Integer> map1 = new HashMap<>();
        map1.put("Ale", 340);
        int num = map1.get("Ale");

        ArrayList<String> a1 = new ArrayList<>();
        // Non si puo' fare perche' ereditarieta' non e' co-variante
        // ArrayList<Object> o1 = a1;

        ArrayList<? extends String> a2 = new ArrayList<>();



        Pair<String> pair3 = new Pair<>("Pippo", "Pluto");

        Iterator<String> it2 = pair3.iterator();
        while (it2.hasNext()) {
            System.out.println(it2.next());
        }

        // Equivalente a quanto scritto sopra
        for (String s : pair3) {
            System.out.println(s);
        }

        List<Integer> myList = new ArrayList<>();
        try {
            GenericsUtils.getFirst(myList);
        } catch (EmptyListException e) {
            System.out.println(e.getMessage());
        }

    }

    public static void stampa(Printable p) {
        p.print();
    }
}
