package it.polimi.softeng.abstract_interfaces;

public interface Printable {
    public void print();
}
