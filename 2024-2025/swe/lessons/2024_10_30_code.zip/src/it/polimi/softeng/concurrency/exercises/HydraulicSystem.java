package it.polimi.softeng.concurrency.exercises;

import java.util.ArrayList;
import java.util.List;

// Tema 20240705
public class HydraulicSystem {
    private List<WaterTank> tanks;

    public HydraulicSystem(int numTanks) {
        tanks = new ArrayList<WaterTank>();
        for (int i=0; i<numTanks; i++) {
            tanks.add(new WaterTank(1000));
        }
    }

    public synchronized void swap(int tank1, int tank2, int water) {
        int waterTaken;
        waterTaken = tanks.get(tank1).take(water);
        tanks.get(tank2).put(waterTaken);
    }

    public synchronized int totalWater() {
        int tot = 0;
        for (WaterTank wt : tanks) {
            tot += wt.getWaterLevel();
        }
        return tot;
    }
}

class WaterTank {
    private int waterLevel;

    public WaterTank(int water) {
        waterLevel = water;
    }

    public synchronized void put(int water) {
        waterLevel += water;
    }

    public synchronized int take(int water) {
        if (water > waterLevel) {
            water = waterLevel; // not enough water
        }
        waterLevel -= water;
        return water;
    }

    public synchronized int getWaterLevel() {
        return waterLevel;
    }
}

// a) Nel suo insieme il codice evita il verificarsi di
// accessi concorrenti a zone condivise di memoria anche
// se i vari metodi fossero invocati da thread diversi?
// Motivare la propria risposta e in caso di risposta
// negativa spiegare cosa andrebbe cambiato per evitare
// conflitti nell’accesso a memoria condivisa.

// b) Data una istanza myHS della classe HydraulicSystem,
// e' corretto affermare che, anche in presenza di thread
// multipli, la chiamata myHS.totalWater() restituisce
// sempre il medesimo valore?
// Motivare la propria risposta e in caso negativo spiegare
// come cambiare il codice proposto, al fine di offrire
// tale garanzia.

// c) Data una istanza myHS della classe HydraulicSystem,
// si scriva il frammento di codice che crea ed avvia
// un thread che esegue all’infinito il seguente codice:
// myHS.swap(1,2,10);
// myHS.swap(2,1,10);
