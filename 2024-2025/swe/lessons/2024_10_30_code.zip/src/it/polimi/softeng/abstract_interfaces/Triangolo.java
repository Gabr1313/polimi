package it.polimi.softeng.abstract_interfaces;

public class Triangolo extends Poligono implements Printable {
    public Triangolo() {
        super(3);
    }

    @Override
    public void draw() {
        System.out.println("Triangolo");
    }

    @Override
    public void print() {
        draw();
    }
}
