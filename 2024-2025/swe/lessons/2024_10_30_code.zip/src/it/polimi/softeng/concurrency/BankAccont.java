package it.polimi.softeng.concurrency;

public class BankAccont {
    private int balance;

    public BankAccont(int balance) {
        this.balance = balance;
    }

    public void deposit(int amount) {
        synchronized (this) {
            this.balance += amount;
            this.notifyAll();
        }
    }

    public synchronized void withdraw(int amount) {
        while (balance < amount) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                System.out.println("Errore!!");
            }
        }
        this.balance -= amount;
    }

    public synchronized int getBalance() {
        return balance;
    }

    public void transfer(BankAccont other, int amount) {
        this.withdraw(amount);
        other.deposit(amount);
// Equivalente al codice sotto
//        synchronized (this) {
//            this.balance -= amount;
//        }
//        synchronized (other) {
//            other.balance += amount;
//        }
    }
}
